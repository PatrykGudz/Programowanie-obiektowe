﻿namespace Helpdesk
{
    partial class FormAddZgloszenie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AddButton = new Button();
            LabelTemat = new Label();
            LabelOpis = new Label();
            TextBoxTemat = new TextBox();
            TextBoxOpis = new TextBox();
            Exit = new Button();
            SuspendLayout();
            // 
            // AddButton
            // 
            AddButton.Location = new Point(20, 245);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(75, 23);
            AddButton.TabIndex = 0;
            AddButton.Text = "Zapisz";
            AddButton.UseVisualStyleBackColor = true;
            AddButton.Click += AddButton_Click;
            // 
            // LabelTemat
            // 
            LabelTemat.AutoSize = true;
            LabelTemat.Location = new Point(19, 37);
            LabelTemat.Name = "LabelTemat";
            LabelTemat.Size = new Size(39, 15);
            LabelTemat.TabIndex = 1;
            LabelTemat.Text = "Temat";
            // 
            // LabelOpis
            // 
            LabelOpis.AutoSize = true;
            LabelOpis.Location = new Point(20, 79);
            LabelOpis.Name = "LabelOpis";
            LabelOpis.Size = new Size(31, 15);
            LabelOpis.TabIndex = 2;
            LabelOpis.Text = "Opis";
            // 
            // TextBoxTemat
            // 
            TextBoxTemat.Location = new Point(86, 34);
            TextBoxTemat.Name = "TextBoxTemat";
            TextBoxTemat.Size = new Size(205, 23);
            TextBoxTemat.TabIndex = 3;
            // 
            // TextBoxOpis
            // 
            TextBoxOpis.Location = new Point(86, 76);
            TextBoxOpis.Multiline = true;
            TextBoxOpis.Name = "TextBoxOpis";
            TextBoxOpis.Size = new Size(205, 163);
            TextBoxOpis.TabIndex = 4;
            // 
            // Exit
            // 
            Exit.Location = new Point(216, 245);
            Exit.Name = "Exit";
            Exit.Size = new Size(75, 23);
            Exit.TabIndex = 5;
            Exit.Text = "Zamknij";
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // FormAddZgloszenie
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(303, 280);
            Controls.Add(Exit);
            Controls.Add(TextBoxOpis);
            Controls.Add(TextBoxTemat);
            Controls.Add(LabelOpis);
            Controls.Add(LabelTemat);
            Controls.Add(AddButton);
            Name = "FormAddZgloszenie";
            Text = "FormAddZgloszenie";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button AddButton;
        private Label LabelTemat;
        private Label LabelOpis;
        private TextBox TextBoxTemat;
        private TextBox TextBoxOpis;
        private Button Exit;
    }
}