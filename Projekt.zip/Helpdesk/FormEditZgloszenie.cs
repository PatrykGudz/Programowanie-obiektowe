﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helpdesk
{
    public partial class FormEditZgloszenie : Form
    {
        private int idZgloszenia; // Przechowuje ID zgłoszenia

        public FormEditZgloszenie(int idZgloszenia, string temat, string opis, string status)
        {
            InitializeComponent();
            this.idZgloszenia = idZgloszenia;

            // Ustawienie tematu jako tylko do odczytu
            TextBoxTemat.Text = temat;
            TextBoxTemat.ReadOnly = true;

            // Ustawienie opisu i statusu do edycji
            TextBoxOpis.Text = opis;
            ComboBoxStatus.SelectedItem = status;
        }

        private void ComboBoxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obsługa zmiany statusu (jeśli potrzebna)
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string nowyOpis = TextBoxOpis.Text.Trim();
            string nowyStatus = ComboBoxStatus.SelectedItem.ToString(); // Sprawdzenie, czy wybrano status

            if (string.IsNullOrWhiteSpace(nowyOpis) || string.IsNullOrWhiteSpace(nowyStatus))
            {
                MessageBox.Show("Opis i status muszą być uzupełnione!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var connection = new SQLiteConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                string updateQuery = "UPDATE Zgloszenia SET opis = @opis, status = @status WHERE id_zgloszenia = @id";
                using (var command = new SQLiteCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@opis", nowyOpis);
                    command.Parameters.AddWithValue("@status", nowyStatus);
                    command.Parameters.AddWithValue("@id", idZgloszenia);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }

            MessageBox.Show("Zgłoszenie zaktualizowane!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close(); // Zamknięcie okna edycji
        }

        private void TextBoxOpis_TextChanged(object sender, EventArgs e)
        {
            // Obsługa zmiany opisu (jeśli potrzebna)
        }

        private void TextBoxTemat_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
