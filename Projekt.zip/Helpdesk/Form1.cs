using Microsoft.VisualBasic.Logging;

namespace Helpdesk
{
    public partial class Form1 : Form
    {
        private string Login = "";
        private string Password = "";

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            Login = UserName.Text;
        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {
            Password = UserPassword.Text;
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }
        private string GetUsernameFromFile(string login, string password, string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Plik z u�ytkownikami nie istnieje!", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                var parts = line.Split(';');
                if (parts.Length == 3 && parts[0] == login && parts[1] == password)
                {
                    return parts[2]; // Zwraca nazw� u�ytkownika
                }
            }
            return null; // Je�li login lub has�o nie pasuj�
        }
        private void button1_Click_1(object sender, EventArgs e)
        {

            string filePath = "C:\\Helpdesk\\users.txt"; // �cie�ka do pliku z u�ytkownikami
            string Login = UserNam.Text.Trim();
            string Password = UserPass.Text.Trim();
            string username = GetUsernameFromFile(Login, Password, filePath);

            if (CheckCredentials(Login, Password, filePath))
            {
                this.Hide(); // Ukrywa Form1 (logowanie)
                Form2 dashboard = new Form2(username);
                dashboard.Show();
                
            }
            else
            {
                MessageBox.Show("Niepoprawne dane logowania!", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool CheckCredentials(string username, string password, string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Plik z u�ytkownikami nie istnieje!", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            var lines = File.ReadAllLines(filePath);
            return lines.Any(line =>
            {
                var parts = line.Split(';');
                return parts.Length == 3 && parts[0] == username && parts[1] == password;
            });
        }

        private void UserNam_TextChanged(object sender, EventArgs e)
        {

        }

        private void UserPass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

