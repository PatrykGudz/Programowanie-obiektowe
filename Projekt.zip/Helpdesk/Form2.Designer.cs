﻿namespace Helpdesk
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            LoginUser = new Label();
            Zgloszenia = new DataGridView();
            Refresh = new Button();
            Add = new Button();
            EditButton = new Button();
            Import = new Button();
            Eksport = new Button();
            DeleteButton = new Button();
            ((System.ComponentModel.ISupportInitialize)Zgloszenia).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(713, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "Wyloguj";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // LoginUser
            // 
            LoginUser.AutoSize = true;
            LoginUser.Location = new Point(613, 16);
            LoginUser.Name = "LoginUser";
            LoginUser.Size = new Size(0, 15);
            LoginUser.TabIndex = 1;
            // 
            // Zgloszenia
            // 
            Zgloszenia.AllowUserToAddRows = false;
            Zgloszenia.AllowUserToDeleteRows = false;
            Zgloszenia.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Zgloszenia.Location = new Point(16, 64);
            Zgloszenia.Name = "Zgloszenia";
            Zgloszenia.ReadOnly = true;
            Zgloszenia.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Zgloszenia.Size = new Size(766, 326);
            Zgloszenia.TabIndex = 2;
            // 
            // Refresh
            // 
            Refresh.Location = new Point(12, 16);
            Refresh.Name = "Refresh";
            Refresh.Size = new Size(75, 23);
            Refresh.TabIndex = 3;
            Refresh.Text = "Odśwież";
            Refresh.UseVisualStyleBackColor = true;
            Refresh.Click += Refresh_Click;
            // 
            // Add
            // 
            Add.Location = new Point(32, 413);
            Add.Name = "Add";
            Add.Size = new Size(104, 23);
            Add.TabIndex = 4;
            Add.Text = "Dodaj zgłoszenie";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // EditButton
            // 
            EditButton.Location = new Point(142, 413);
            EditButton.Name = "EditButton";
            EditButton.Size = new Size(75, 23);
            EditButton.TabIndex = 5;
            EditButton.Text = "Edytuj";
            EditButton.UseVisualStyleBackColor = true;
            EditButton.Click += EditButton_Click;
            // 
            // Import
            // 
            Import.Location = new Point(676, 413);
            Import.Name = "Import";
            Import.Size = new Size(106, 23);
            Import.TabIndex = 6;
            Import.Text = "Importuj z CSV";
            Import.UseVisualStyleBackColor = true;
            Import.Click += Import_Click;
            // 
            // Eksport
            // 
            Eksport.Location = new Point(566, 413);
            Eksport.Name = "Eksport";
            Eksport.Size = new Size(104, 23);
            Eksport.TabIndex = 7;
            Eksport.Text = "Eksportuj z CSV";
            Eksport.UseVisualStyleBackColor = true;
            Eksport.Click += Eksport_Click;
            // 
            // DeleteButton
            // 
            DeleteButton.Location = new Point(223, 413);
            DeleteButton.Name = "DeleteButton";
            DeleteButton.Size = new Size(75, 23);
            DeleteButton.TabIndex = 8;
            DeleteButton.Text = "Usuń";
            DeleteButton.UseVisualStyleBackColor = true;
            DeleteButton.Click += DeleteButton_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteButton);
            Controls.Add(Eksport);
            Controls.Add(Import);
            Controls.Add(EditButton);
            Controls.Add(Add);
            Controls.Add(Refresh);
            Controls.Add(Zgloszenia);
            Controls.Add(LoginUser);
            Controls.Add(button1);
            Name = "Form2";
            Text = "Helpdesk";
            ((System.ComponentModel.ISupportInitialize)Zgloszenia).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label LoginUser;
        private DataGridView Zgloszenia;
        private Button Refresh;
        private Button Add;
        private Button EditButton;
        private Button Import;
        private Button Eksport;
        private Button DeleteButton;
    }
}