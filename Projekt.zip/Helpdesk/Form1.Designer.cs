﻿namespace Helpdesk
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserName = new Label();
            UserPassword = new Label();
            button1 = new Button();
            UserPass = new TextBox();
            UserNam = new TextBox();
            SuspendLayout();
            // 
            // UserName
            // 
            UserName.AutoSize = true;
            UserName.Location = new Point(69, 21);
            UserName.Name = "UserName";
            UserName.Size = new Size(112, 15);
            UserName.TabIndex = 1;
            UserName.Text = "Nazwa Użytkownika";
            // 
            // UserPassword
            // 
            UserPassword.AutoSize = true;
            UserPassword.Location = new Point(97, 87);
            UserPassword.Name = "UserPassword";
            UserPassword.Size = new Size(37, 15);
            UserPassword.TabIndex = 2;
            UserPassword.Text = "Hasło";
            // 
            // button1
            // 
            button1.Location = new Point(81, 158);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 3;
            button1.Text = "Zaloguj";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // UserPass
            // 
            UserPass.Location = new Point(69, 118);
            UserPass.Name = "UserPass";
            UserPass.PasswordChar = '*';
            UserPass.Size = new Size(100, 23);
            UserPass.TabIndex = 4;
            UserPass.TextChanged += UserPass_TextChanged;
            // 
            // UserNam
            // 
            UserNam.Location = new Point(69, 50);
            UserNam.Name = "UserNam";
            UserNam.Size = new Size(100, 23);
            UserNam.TabIndex = 5;
            UserNam.TextChanged += UserNam_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(234, 211);
            Controls.Add(UserNam);
            Controls.Add(UserPass);
            Controls.Add(button1);
            Controls.Add(UserPassword);
            Controls.Add(UserName);
            Name = "Form1";
            Text = "Logowanie";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label UserName;
        private Label UserPassword;
        private Button button1;
        private TextBox UserPass;
        private TextBox UserNam;
    }
}
