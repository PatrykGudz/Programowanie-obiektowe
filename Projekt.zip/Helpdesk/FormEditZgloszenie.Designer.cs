﻿namespace Helpdesk
{
    partial class FormEditZgloszenie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TextBoxTemat = new TextBox();
            TextBoxOpis = new TextBox();
            LabelEditOpis = new Label();
            ComboBoxStatus = new ComboBox();
            SaveButton = new Button();
            LabelStatus = new Label();
            SuspendLayout();
            // 
            // TextBoxTemat
            // 
            TextBoxTemat.Location = new Point(12, 26);
            TextBoxTemat.Name = "TextBoxTemat";
            TextBoxTemat.ReadOnly = true;
            TextBoxTemat.Size = new Size(384, 23);
            TextBoxTemat.TabIndex = 0;
            TextBoxTemat.TextAlign = HorizontalAlignment.Center;
            TextBoxTemat.TextChanged += TextBoxTemat_TextChanged;
            // 
            // TextBoxOpis
            // 
            TextBoxOpis.Location = new Point(12, 89);
            TextBoxOpis.Multiline = true;
            TextBoxOpis.Name = "TextBoxOpis";
            TextBoxOpis.Size = new Size(384, 127);
            TextBoxOpis.TabIndex = 1;
            TextBoxOpis.TextChanged += TextBoxOpis_TextChanged;
            // 
            // LabelEditOpis
            // 
            LabelEditOpis.AutoSize = true;
            LabelEditOpis.Location = new Point(182, 62);
            LabelEditOpis.Name = "LabelEditOpis";
            LabelEditOpis.Size = new Size(31, 15);
            LabelEditOpis.TabIndex = 2;
            LabelEditOpis.Text = "Opis";
            // 
            // ComboBoxStatus
            // 
            ComboBoxStatus.FormattingEnabled = true;
            ComboBoxStatus.Items.AddRange(new object[] { "Otwarty", "W toku", "Zamknięty" });
            ComboBoxStatus.Location = new Point(12, 256);
            ComboBoxStatus.Name = "ComboBoxStatus";
            ComboBoxStatus.Size = new Size(121, 23);
            ComboBoxStatus.TabIndex = 3;
            ComboBoxStatus.SelectedIndexChanged += ComboBoxStatus_SelectedIndexChanged;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(321, 255);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(75, 23);
            SaveButton.TabIndex = 4;
            SaveButton.Text = "Zapisz";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // LabelStatus
            // 
            LabelStatus.AutoSize = true;
            LabelStatus.Location = new Point(48, 228);
            LabelStatus.Name = "LabelStatus";
            LabelStatus.Size = new Size(39, 15);
            LabelStatus.TabIndex = 5;
            LabelStatus.Text = "Status";
            // 
            // FormEditZgloszenie
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(408, 303);
            Controls.Add(LabelStatus);
            Controls.Add(SaveButton);
            Controls.Add(ComboBoxStatus);
            Controls.Add(LabelEditOpis);
            Controls.Add(TextBoxOpis);
            Controls.Add(TextBoxTemat);
            Name = "FormEditZgloszenie";
            Text = "FormEditZgloszenie";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TextBoxTemat;
        private TextBox TextBoxOpis;
        private Label LabelEditOpis;
        private ComboBox ComboBoxStatus;
        private Button SaveButton;
        private Label LabelStatus;
    }
}