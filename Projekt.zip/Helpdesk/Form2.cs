﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Helpdesk
{
    public partial class Form2 : Form
    {
        private string username;

        public Form2(string username)
        {
            InitializeComponent();
            this.username = username;
            LoadZgloszenia();
            LoginUser.Text = username;
        }
        private void LoadZgloszenia()
        {
            using (var connection = new SQLiteConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                string query = "SELECT * FROM Zgloszenia";
                using (var command = new SQLiteCommand(query, connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        Zgloszenia.DataSource = table;
                    }
                }
                connection.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void Zgloszenia_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            LoadZgloszenia();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            FormAddZgloszenie addForm = new FormAddZgloszenie(username);
            addForm.ShowDialog();
            LoadZgloszenia();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (Zgloszenia.SelectedRows.Count == 0)
            {
                MessageBox.Show("Wybierz zgłoszenie do edycji!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Pobranie danych z zaznaczonego wiersza
            int idZgloszenia = Convert.ToInt32(Zgloszenia.SelectedRows[0].Cells["id_zgloszenia"].Value);
            string temat = Zgloszenia.SelectedRows[0].Cells["temat"].Value.ToString();
            string opis = Zgloszenia.SelectedRows[0].Cells["opis"].Value.ToString();
            string status = Zgloszenia.SelectedRows[0].Cells["status"].Value.ToString();

            // Otworzenie okna edycji i przekazanie danych
            FormEditZgloszenie editForm = new FormEditZgloszenie(idZgloszenia, temat, opis, status);
            editForm.ShowDialog();

            // Odświeżenie listy po edycji
            LoadZgloszenia();
        }

        private void Import_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Plik CSV (*.csv)|*.csv",
                Title = "Wybierz plik CSV"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ImportujZCSV(openFileDialog.FileName);
                LoadZgloszenia(); // Odświeżenie widoku po imporcie
            }
        }

        private void ImportujZCSV(string filePath)
        {
            try
            {
                using (var connection = new SQLiteConnection(DatabaseHelper.GetConnectionString()))
                {
                    connection.Open();
                    using (var reader = new StreamReader(filePath, Encoding.UTF8))
                    {
                        bool firstLine = true;
                        while (!reader.EndOfStream)
                        {
                            string line = reader.ReadLine();
                            if (firstLine) // Pomijamy nagłówki
                            {
                                firstLine = false;
                                continue;
                            }

                            string[] values = line.Split(';');
                            if (values.Length != 4) continue; // Sprawdzenie poprawności danych

                            // 🔹 Pobieranie danych BEZ ID
                            string zglaszajacy = values[0];
                            string temat = values[1];
                            string opis = values[2];
                            string status = values[3];

                            // 🔹 Wstawianie do bazy (BEZ ID)
                            string insertQuery = "INSERT INTO Zgloszenia (zglaszajacy, temat, opis, status) VALUES (@zglaszajacy, @temat, @opis, @status)";
                            using (var command = new SQLiteCommand(insertQuery, connection))
                            {
                                command.Parameters.AddWithValue("@zglaszajacy", zglaszajacy);
                                command.Parameters.AddWithValue("@temat", temat);
                                command.Parameters.AddWithValue("@opis", opis);
                                command.Parameters.AddWithValue("@status", status);
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    connection.Close();
                }

                MessageBox.Show("Dane zaimportowano pomyślnie!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadZgloszenia(); // 🔹 Odświeżenie widoku po imporcie
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd importu: " + ex.Message, "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Eksport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Plik CSV (*.csv)|*.csv",
                Title = "Zapisz jako CSV",
                FileName = "zgłoszenia.csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                EksportujDoCSV(saveFileDialog.FileName);
            }
        }
        private void EksportujDoCSV(string filePath)
        {
            try
            {
                StringBuilder csvContent = new StringBuilder();

                // 🔹 Pobranie nagłówków kolumn BEZ ID
                csvContent.AppendLine("zglaszajacy;temat;opis;status");

                // 🔹 Pobranie danych z DataGridView BEZ ID
                foreach (DataGridViewRow row in Zgloszenia.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        string zglaszajacy = row.Cells["zglaszajacy"].Value?.ToString();
                        string temat = row.Cells["temat"].Value?.ToString();
                        string opis = row.Cells["opis"].Value?.ToString();
                        string status = row.Cells["status"].Value?.ToString();

                        csvContent.AppendLine($"{zglaszajacy};{temat};{opis};{status}");
                    }
                }

                // 🔹 Zapis do pliku
                File.WriteAllText(filePath, csvContent.ToString(), Encoding.UTF8);
                MessageBox.Show("Dane zostały wyeksportowane do CSV!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd eksportu: " + ex.Message, "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (Zgloszenia.SelectedRows.Count == 0)
            {
                MessageBox.Show("Wybierz przynajmniej jedno zgłoszenie do usunięcia!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Potwierdzenie usunięcia
            DialogResult result = MessageBox.Show($"Czy na pewno chcesz usunąć {Zgloszenia.SelectedRows.Count} zgłoszeń?",
                                                  "Potwierdzenie", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                using (var connection = new SQLiteConnection(DatabaseHelper.GetConnectionString()))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            foreach (DataGridViewRow row in Zgloszenia.SelectedRows)
                            {
                                if (row.Cells["id_zgloszenia"].Value != null)
                                {
                                    int idZgloszenia = Convert.ToInt32(row.Cells["id_zgloszenia"].Value);
                                    string deleteQuery = "DELETE FROM Zgloszenia WHERE id_zgloszenia = @id";

                                    using (var command = new SQLiteCommand(deleteQuery, connection, transaction))
                                    {
                                        command.Parameters.AddWithValue("@id", idZgloszenia);
                                        command.ExecuteNonQuery();
                                    }
                                }
                            }

                            transaction.Commit();
                            MessageBox.Show("Wybrane zgłoszenia zostały usunięte!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Błąd usuwania: " + ex.Message, "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    connection.Close();
                }

                LoadZgloszenia(); // 🔹 Odświeżenie listy po usunięciu
            }
        }
    }
}
