﻿using System;
using System.Data.SQLite;
using System.IO;

namespace Helpdesk
{
    public static class DatabaseHelper
    {
        // 🔹 Tworzy bazę w katalogu głównym projektu
        private static string dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\helpdesk.db");
        private static string connectionString = $"Data Source={dbPath};Version=3;";

        public static void InitializeDatabase()
        {
            try
            {
                if (!File.Exists(dbPath))
                {
                    Console.WriteLine("🔹 Tworzenie bazy danych: " + Path.GetFullPath(dbPath));
                    SQLiteConnection.CreateFile(dbPath);
                }

                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    string createTableQuery = @"
                        CREATE TABLE IF NOT EXISTS Zgloszenia (
                            id_zgloszenia INTEGER PRIMARY KEY AUTOINCREMENT,
                            zglaszajacy TEXT NOT NULL,
                            temat TEXT NOT NULL,
                            opis TEXT NOT NULL,
                            status TEXT NOT NULL
                        );";
                    using (var command = new SQLiteCommand(createTableQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }

                Console.WriteLine("✅ Baza danych i tabela zostały utworzone!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Błąd inicjalizacji bazy: " + ex.Message);
            }
        }

        public static void CheckTables()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT name FROM sqlite_master WHERE type='table' AND name='Zgloszenia'";
                using (var command = new SQLiteCommand(query, connection))
                {
                    var result = command.ExecuteScalar();
                    if (result != null)
                        Console.WriteLine("✅ Tabela Zgloszenia istnieje!");
                    else
                        Console.WriteLine("❌ Tabela Zgloszenia NIE ISTNIEJE!");
                }
                connection.Close();
            }
        }

        public static string GetConnectionString()
        {
            return connectionString;
        }
    }
}
