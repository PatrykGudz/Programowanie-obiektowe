﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helpdesk
{
    public partial class FormAddZgloszenie : Form
    {
        private string username;
        public FormAddZgloszenie(string username)
        {
            InitializeComponent();
            this.username = username;
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            string zglaszajacy = username;
            string temat = TextBoxTemat.Text.Trim();
            string opis = TextBoxOpis.Text.Trim();
            string status = "Otwarty";

            if (string.IsNullOrWhiteSpace(zglaszajacy) || string.IsNullOrWhiteSpace(temat) ||
                string.IsNullOrWhiteSpace(opis) || string.IsNullOrWhiteSpace(status))
            {
                MessageBox.Show("Wypełnij wszystkie pola!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var connection = new SQLiteConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Zgloszenia (zglaszajacy, temat, opis, status) VALUES (@zglaszajacy, @temat, @opis, @status)";
                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@zglaszajacy", zglaszajacy);
                    command.Parameters.AddWithValue("@temat", temat);
                    command.Parameters.AddWithValue("@opis", opis);
                    command.Parameters.AddWithValue("@status", status);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }

            MessageBox.Show("Zgłoszenie dodane pomyślnie!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close(); // Zamknięcie okna po zapisaniu
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
